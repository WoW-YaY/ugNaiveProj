//  Demo.c
//  MachineLearning
//
//  Created by Jiahui Ye
//  {/ o o /} {/ . . /} {/ ^ ^ /}
//  ( (o o) ) ( (o o) ) ( (o o) )
//  www.yjh.cn@gmail.com

#include <stdio.h>
#include <math.h>

int main() {
    //  linear regression demo
    printf("\nlinear regression demo:\n");
    void linear_regression(double x_data[], double y_data[], double b, double w, double lr, int iteration, int n);
    double x_data[10] = {338, 333, 328, 207, 226, 25, 179, 60, 208, 606};
    double y_data[10] = {640, 633, 619, 393, 428, 27, 193, 66, 226, 1591};
    linear_regression(x_data, y_data, -150, -3, 1, 100000, 10);
    printf("\n");
    
    //  naive bayes demo
    printf("\nnaive bayes demo:\n");
    void naive_bayes(double x_train0[][2],double x_train1[][2],double test[][2],int num0,int num1,int numx);
    double x_train0[8][2] = {{4,4},{4,6},{4,8},{6,8},{8,8},{8,6},{8,4},{6,4}};
    double x_train1[8][2] = {{0,0},{4,4},{0,4},{4,0},{2,4},{4,2},{0,2},{2,0}};
    double test_nb[6][2] = {{-2,-1},{3,2},{2,3},{4,6},{5,5},{9,6}};
    naive_bayes(x_train0,x_train1,test_nb,8,8,6);
    printf("\n");
    
    //  logistic regression demo
    printf("\nlogistic regression demo:\n");
    void logistic_regression(double C0[][3],double C1[][3],double C2[][3],double test[][3],int num0,int num1,int num2,int numx,double lr,int iteration);
    double C0[8][3] = {{4,4,4},{4,6,5},{4,8,6},{6,8,7},{8,8,8},{8,6,7},{8,4,6},{6,4,5}};
    double C1[8][3] = {{0,0,0},{4,4,4},{0,4,2},{4,0,2},{2,4,3},{4,2,3},{0,2,1},{2,0,1}};
    double C2[8][3] = {{4,4,4},{8,10,9},{4,12,8},{10,8,9},{10,12,11},{12,8,10},{8,6,7},{8,4,6}};
    double test_lr[6][3] = {{-2,-1,-1},{3,2,-5},{2,3,6},{4,6,5},{3,6,2},{9,6,8}};
    logistic_regression(C0,C1,C2,test_lr,8,8,8,6,0.2,10);
    printf("\n");
    
    //  perceptron demo
    printf("\nperceptron demo:\n");
    void perceptron(double C0[][2],double C1[][2],double test[][2],int num0,int num1,int numx,double lr,int iteration);
    double test_p[4][2] = {{2,-1},{-3,-3},{4,4},{2,8}};
    perceptron(x_train0,x_train1,test_p,8,8,4,0.2,10);
    printf("\n");
    
    //  backpropagation demo
    printf("\nbackpropagation demo:\n");
    void backpropagation(double x_data[][2],double y_data[][2],double test[][2],double lr,int iteration,int n,int numx);
    double train[8][2] = {{8,8},{8,6},{8,4},{6,4},{0,0},{4,4},{0,4},{4,0}};
    double target[8][2] = {{0,1},{0,1},{0,1},{0,1},{1,0},{1,0},{1,0},{1,0}};
    double test[4][2] = {{0,3},{3,2},{2,2},{4,6}};
    backpropagation(train,target,test,0.2,10,8,4);
    printf("\n");
    
}
