//  LinearRegression.c
//  MachineLearning
//
//  Created by Jiahui Ye
//  {/ o o /} {/ . . /} {/ ^ ^ /}
//  ( (o o) ) ( (o o) ) ( (o o) )
//  www.yjh.cn@gmail.com

#include <stdio.h>
#include <math.h>

void linear_regression(double x_data[],double y_data[],double b,double w,double lr,int iteration,int n) {
    //  w is initial weight, b is initial bias, y = w * x + b
    //  lr is initial learning rate, iteration is the times of learning, n is the number of examples
    //  and this function prints the weight and the bias of this linear regression model
    
    int i,j;
    double b_grad,w_grad;  //  gradient of b and w
    double lr_b = 0;
    double lr_w = 0;
    
    for(i=0; i<iteration; i++)
    {
        b_grad = 0;
        w_grad = 0;
        
        for (j=0; j<n; j++)  //  gradient descent
        {
            b_grad = b_grad - 2.0 * (y_data[j] - b - w * x_data[j]) * 1.0;
            w_grad = w_grad - 2.0 * (y_data[j] - b - w * x_data[j]) * x_data[j];
        }
        
        //  Adagrad
        lr_b = lr_b + pow(b_grad,2);
        lr_w = lr_w + pow(w_grad,2);
        
        //  update parameters
        b = b - lr/sqrt(lr_b) * b_grad;
        w = w - lr/sqrt(lr_w) * w_grad;
    }
    
    printf("b=%lf\tw=%lf\n",b,w);
}
