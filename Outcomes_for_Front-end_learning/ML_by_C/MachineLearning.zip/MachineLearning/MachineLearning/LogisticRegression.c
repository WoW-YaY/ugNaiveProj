//  LogisticRegression.c
//  MachineLearning
//
//  Created by Jiahui Ye
//  {/ o o /} {/ . . /} {/ ^ ^ /}
//  ( (o o) ) ( (o o) ) ( (o o) )
//  www.yjh.cn@gmail.com

#include <stdio.h>
#include <math.h>

double sigmoid(double x) {
    double ex;
    ex = pow(2.718281828,x);
    return ex/(1+ex);
}

void logistic_regression(double C0[][3],double C1[][3],double C2[][3],double test[][3],int num0,int num1,int num2,int numx,double lr,int iteration) {
    //  lr is initial learning rate, iteration is the times of learning
    //  Ci is the examples whose label is i, numi is the number of examples in Ci
    //  test is a test set, numx is the size of test set
    //  in this function simulate multivariate+multiclass, i.e. three features and three classes
    //  and this function prints the classification of the test set
    
    int n,i,j,k;
    double w[3][3]={{0,0,0},{0,0,0},{0,0,0}};

    for(n=0; n<iteration; n++)
    {
        for(i=0; i<num0; i++) {
            w[0][0] -= lr * (sigmoid(C0[i][0]*w[0][0]+C0[i][1]*w[0][1]+C0[i][2]*w[0][2])-1) * C0[i][0];
            w[0][1] -= lr * (sigmoid(C0[i][0]*w[1][0]+C0[i][1]*w[1][1]+C0[i][2]*w[1][2])-0) * C0[i][1];
            w[0][2] -= lr * (sigmoid(C0[i][0]*w[2][0]+C0[i][1]*w[2][1]+C0[i][2]*w[2][2])-0) * C0[i][2];
        }
        for(j=0; j<num1; j++) {
            w[1][0] -= lr * (sigmoid(C1[j][0]*w[0][0]+C1[j][1]*w[0][1]+C1[j][2]*w[0][2])-0) * C1[j][0];
            w[1][1] -= lr * (sigmoid(C1[j][0]*w[1][0]+C1[j][1]*w[1][1]+C1[j][2]*w[1][2])-1) * C1[j][1];
            w[1][2] -= lr * (sigmoid(C1[j][0]*w[2][0]+C1[j][1]*w[2][1]+C1[j][2]*w[2][2])-0) * C1[j][2];
        }
        for(k=0; k<num2; k++) {
            w[2][0] -= lr * (sigmoid(C2[k][0]*w[0][0]+C2[k][1]*w[0][1]+C2[k][2]*w[0][2])-0) * C2[k][0];
            w[2][1] -= lr * (sigmoid(C2[k][0]*w[1][0]+C2[k][1]*w[1][1]+C2[k][2]*w[1][2])-0) * C2[k][1];
            w[2][2] -= lr * (sigmoid(C2[k][0]*w[2][0]+C2[k][1]*w[2][1]+C2[k][2]*w[2][2])-1) * C2[k][2];
        }
    }
    
    double z[3];
    for (n=0; n<numx; n++) {
        //  compute the probability of each class
        for (i=0;i<3;i++)
            z[i] = w[i][0]*test[n][0]+w[i][1]*test[n][1]+w[i][2]*test[n][2];
        
        printf("ID:%d\t",n);
        
        //  softmax
        double sumex;
        sumex = (exp(z[0]) + exp(z[1]) + exp(z[2]));
        double result[3];
        for (i=0;i<3;i++) {
            result[i] = exp(z[i])/sumex;
            printf("%f\t",result[i]);
        }
        int class_number;
        if((result[0]>=result[1]) && (result[0]>=result[2]))
            class_number = 0;
        else if((result[1]>=result[0]) && (result[1]>=result[2]))
            class_number = 1;
        else
            class_number = 2;
        printf("Class %d  (start from 0)\n",class_number);
    }
}
