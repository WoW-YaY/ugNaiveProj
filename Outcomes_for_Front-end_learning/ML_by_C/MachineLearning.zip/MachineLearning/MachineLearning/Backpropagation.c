//  Backpropagation.c
//  MachineLearning
//
//  Created by Jiahui Ye
//  {/ o o /} {/ . . /} {/ ^ ^ /}
//  ( (o o) ) ( (o o) ) ( (o o) )
//  www.yjh.cn@gmail.com

#include <stdio.h>
#include <math.h>

//  activation function we choose sigmoid
//  !!! please copy it from LogisticRegression.c if you do not open it as a whole project
double sigmoid(double x);

void backpropagation(double x_data[][2],double y_data[][2],double test[][2],double lr,int iteration,int n,int numx) {
    //  in this example, we have two features, two output and one hidden layer
    //  the model is a fully connect neural network
    //  lr is initial learning rate, iteration is the times of learning, n is the number of examples
    //  and this function prints the weight and the bias of this model
    
    int i,j,k,l;
    
    double w1[2][2]={{0.2,0.2},{0.2,0.2}};
    double w2[2][2]={{0.3,0.3},{0.3,0.3}};
    double b1[2]={0.1,0.1};
    double b2[2]={0.2,0.2};
    
    for (i=0;i<iteration;i++) {
        for (j=0;j<n;j++) {
            double z[2],y[2];
            for (k=0;k<2;k++)
                z[k] = sigmoid(w1[k][0]*x_data[j][0]+w1[k][1]*x_data[j][1]+b1[k]);
            for (k=0;k<2;k++)
                y[k] = sigmoid(w2[k][0]*z[0]+w2[k][1]*z[1]+b2[k]);
            
            //  softmax
            double sumex;
            sumex = exp(y[0])+exp(y[1]);
            for (k=0;k<2;k++)
                y[k] = exp(y[k])/sumex;
            
            //  cross entropy between y and target
            double error;
            error = - (y_data[j][0]*log(y[0])+y_data[j][1]*log(y[1]));
            
            //  update the parameters
            //  chain rule
            //  w2
            for (k=0;k<2;k++)
                for (l=0;l<2;l++)
                    w2[l][k] -= lr * (-y_data[j][l]/y[l])*(sigmoid(w2[l][0]*z[0]+w2[l][1]*z[1]+b2[l])*(1-sigmoid(w2[l][0]*z[0]+w2[l][1]*z[1]+b2[l])))*z[k];
            
            //  w1
            double backword_pass_matrix[2];
            for (l=0;l<2;l++)
                    backword_pass_matrix[l] = (-y_data[j][l]/y[l])*(sigmoid(w2[l][0]*z[0]+w2[l][1]*z[1]+b2[l])*(1-sigmoid(w2[l][0]*z[0]+w2[l][1]*z[1]+b2[l])));
            
            double x[2];
            for (k=0;k<2;k++)
                x[k] = w1[k][0]*x_data[j][0]+w1[k][1]*x_data[j][1]+b1[k];
            for (k=0;k<2;k++)
                for (l=0;l<2;l++)
                    w1[l][k] -= lr * x_data[j][k] * sigmoid(x[l]) * (1-sigmoid(x[l])) * (w2[0][l]*backword_pass_matrix[0]+w2[1][l]*backword_pass_matrix[1]);
        }
    }
    
    //  print the parameters
    printf("the parameter is trained as following:\nw1:\n");
    for (i=0;i<2;i++) {
        for (j=0;j<2;j++)
            printf("%f\t",w1[i][j]);
        printf("\n");
    }
    printf("w2:\n");
    for (i=0;i<2;i++) {
        for (j=0;j<2;j++)
            printf("%f\t",w2[i][j]);
        printf("\n");
    }
    
    for (i=0;i<numx;i++) {
        double z[2],t[2];
        for (k=0;k<2;k++)
            z[k] = sigmoid(w1[k][0]*test[i][0]+w1[k][1]*test[i][1]+b1[k]);
        for (k=0;k<2;k++)
            t[k] = sigmoid(w2[k][0]*z[0]+w2[k][1]*z[1]+b2[k]);
        
        //  softmax
        double sumex;
        sumex = exp(t[0])+exp(t[1]);
        for (k=0;k<2;k++)
            t[k] = exp(t[k])/sumex;
        
        printf("ID:%d\t",i);
        for (k=0;k<2;k++)
            printf("%f\t",t[k]);
        printf("\n");
        
    }
}
