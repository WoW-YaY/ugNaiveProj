//  Perceptron.c
//  MachineLearning
//
//  Created by Jiahui Ye
//  {/ o o /} {/ . . /} {/ ^ ^ /}
//  ( (o o) ) ( (o o) ) ( (o o) )
//  www.yjh.cn@gmail.com

#include <stdio.h>
#include <math.h>

int pcn_out(double x) {
    if (x>=0)
        return 1;
    else
        return 0;
}

void perceptron(double C0[][2],double C1[][2],double test[][2],int num0,int num1,int numx,double lr,int iteration) {
    //  lr is initial learning rate, iteration is the times of learning
    //  C0 is the examples whose label is 0, C1 is the examples whose label is 1
    //  num0 is the number of examples in C0, num1 is the number of examples in C1
    //  test is a test set, numx is the size of test set
    //  in this function just set two features and two classes
    //  and this function prints the classification of the test set
    
    int i,j,k,n;
    double w[3]={0.1,0.2};
    for (i=0; i<iteration; i++)
    {
        for (j=0; j<num0; j++)
            for (n=0;n<2;n++)
                w[n] -= lr*(pcn_out(w[0]*C0[j][0]+w[1]*C0[j][1])-0)*C0[j][n];
        for (k=0; k<num1; k++)
            for (n=0;n<2;n++)
                w[n] -= lr*(pcn_out(w[0]*C1[k][0]+w[1]*C1[k][1])-1)*C1[k][n];
    }
    
    int class_number;
    for (n=0; n<numx; n++) {
        printf("ID:%d\t",n);
        class_number = pcn_out(w[0]*test[n][0]+w[1]*test[n][1]+w[2]*(-1));
        printf("Class %d  (start from 0)\n",class_number);
    }
}
