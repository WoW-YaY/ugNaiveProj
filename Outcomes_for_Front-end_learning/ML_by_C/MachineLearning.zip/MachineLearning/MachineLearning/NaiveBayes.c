//  NaiveBayes.c
//  MachineLearning
//
//  Created by Jiahui Ye
//  {/ o o /} {/ . . /} {/ ^ ^ /}
//  ( (o o) ) ( (o o) ) ( (o o) )
//  www.yjh.cn@gmail.com

#include <stdio.h>
#include <math.h>

void naive_bayes(double x_train0[][2],double x_train1[][2],double test[][2],int num0,int num1,int numx) {
    //  x_train0 is the examples whose label is 0, x_train1 is the examples whose label is 1
    //  num0 is the number of examples in x_train0, num1 is the number of examples in x_train1
    //  test is a test set, numx is the size of test set, in this function just set two features
    //  and this function prints the classification of the test set
    
    double mean0[2],mean1[2];
    //  mean0[0] means the mean of feature_1 of x_train0 set, others are the same
    int i,j;
    
    //  compute the mean
    double sum0[2]={0,0};
    for (i=0;i<num0;i++) {
        sum0[0] += x_train0[i][0];
        sum0[1] += x_train0[i][1];
    }
    mean0[0] = sum0[0]/num0;
    mean0[1] = sum0[1]/num0;
    
    double sum1[2]={0,0};
    for (j=0;j<num1;j++) {
        sum1[0] += x_train1[i][0];
        sum1[1] += x_train1[i][1];
    }
    mean1[0] = sum1[0]/num1;
    mean1[1] = sum1[1]/num1;
    
    //  compute the covariance
    double cov0[2][2] = {{0,0},{0,0}};
    double cov1[2][2] = {{0,0},{0,0}};
    for (i=0;i<num0;i++) {
        cov0[0][0] += pow((x_train0[i][0] - mean0[0]),2) / num0;
        cov0[1][1] += pow((x_train0[i][1] - mean0[1]),2) / num0;
        for (j=0;j<num0;j++) {
            cov0[0][1] += x_train0[i][0] * x_train0[j][1] / num0;
        }
    }
    cov0[1][0] = cov0[0][1];
    
    for (i=0;i<num1;i++) {
        cov1[0][0] += pow((x_train1[i][0] - mean1[0]),2) / num1;
        cov1[1][1] += pow((x_train1[i][1] - mean1[1]),2) / num1;
        for (j=0;j<num0;j++) {
            cov1[0][1] += x_train1[i][0] * x_train1[j][1] / num1;
        }
    }
    cov1[1][0] = cov1[0][1];
    
    //  adapted with the same covariance
    double cov[2][2] = {{0,0},{0,0}};
    for (i=0;i<2;i++) {
        for (j=0;j<2;j++) {
            cov[i][j] = (num0*cov0[i][j] + num1*cov1[i][j]) / (num0+num1);
        }
    }
    
    //  compute the posterior probability P(C0|x)
    
    double y[numx];
    
    //  compute the inverse matrix of covariance matrix
    double cov_i[2][2] = {{0,0},{0,0}};
    double det;
    det = (cov[0][0]*cov[1][1]) - (cov[0][1]*cov[1][0]);
    cov_i[0][0] = cov[1][1] / det;
    cov_i[0][1] = cov[0][1] * (-1) / det;
    cov_i[1][0] = cov[1][0] * (-1) / det;
    cov_i[1][1] = cov[0][0] / det;
    
    for (i=0;i<numx;i++) {
        y[i] = 0;
        y[i] += ((mean0[0]-mean1[0])*cov_i[0][0] + (mean0[1]-mean1[1])*cov_i[1][0]) * test[i][0];
        y[i] += ((mean0[0]-mean1[0])*cov_i[0][1] + (mean0[1]-mean1[1])*cov_i[1][1]) * test[i][1];
        y[i] -= 0.5 * (mean0[0]*cov_i[0][0] + mean0[1]*cov_i[1][0]) * mean0[0];
        y[i] -= 0.5 * (mean0[0]*cov_i[0][1] + mean0[1]*cov_i[1][1]) * mean0[1];
        y[i] += 0.5 * (mean1[0]*cov_i[0][0] + mean1[1]*cov_i[1][0]) * mean1[0];
        y[i] += 0.5 * (mean1[0]*cov_i[0][1] + mean1[1]*cov_i[1][1]) * mean1[1];
        y[i] += log(num0/num1);
        
        if (y[i]>=0)
            y[i] = 0;
        else
            y[i] = 1;
    }
    for (i=0;i<numx;i++) {
        printf("ID:%d\tClass:%.0f\n",i,y[i]);
    }
}
