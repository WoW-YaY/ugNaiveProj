// miniprogram/pages/predict/predict.js
Page({
  record: function (e) {
    var num_0 = 0;
    var num_1 = 0;
    var num_2 = 0;
    var num_3 = 0;
    var which;
    const action = ["步行", "深蹲起", "原地跳绳", "俄罗斯转体"];
    const w01 = [-131.8615692, 164.81643459, -140.13035896, -17.35539898, 17.05341088, -9.85931782];
    const b01 = 108.00150534876337;
    const w02 = [-72.55041071, 78.86601791, 190.15920036, -21.48715177, 59.61510141, 9.2582431];
    const b02 = 127.92364840732014;
    const w03 = [34.40404006, 42.79664387, 2.96575005, -5.15931504, 11.21616764, -25.07972435];
    const b03 = -41.56378128648422;
    const w12 = [15.73410657, -96.54399837, 216.19190735, 47.9501017, 19.90279661, 88.41873209];
    const b12 = 68.70637903808141;
    const w13 = [27.69925221, -54.96194812, 29.96976569, 4.82130912, 15.83690774, 9.40519745];
    const b13 = -24.878088711637304;
    const w23 = [7.11520538, 21.91705169, -43.80451619, -9.85891408, -21.46563562, -16.64054651];
    const b23 = -33.6585453055648;
    var acc_x = [];
    var acc_y = [];
    var acc_z = [];
    var gyr_x = [];
    var gyr_y = [];
    var gyr_z = [];

    wx.startAccelerometer({
      interval: 'game'
    })
    wx.startGyroscope({
      interval: 'game'
    })
    wx.onAccelerometerChange(function (res_a) {
      acc_x.push(res_a.x);
      acc_y.push(res_a.y);
      acc_z.push(res_a.z);
    })
    wx.onGyroscopeChange(function (res_g) {
      gyr_x.push(res_g.x);
      gyr_y.push(res_g.y);
      gyr_z.push(res_g.z);
    })
    
    setTimeout(function () {
      // feature generate
      var f = [];
      var i;
      var sum1 = 0;
      for (i = 100; i < 228; i++)
        sum1 += acc_x[i];
      f.push(sum1 / 128);

      var sum2 = 0;
      for (i = 100; i < 228; i++)
        sum2 += acc_y[i];
      f.push(sum2 / 128);

      var sum3 = 0;
      for (i = 100; i < 228; i++)
        sum3 += acc_z[i];
      f.push(sum3 / 128);

      var sum4 = 0;
      for (i = 100; i < 228; i++)
        sum4 += gyr_x[i];
      f.push(sum4 / 128);

      var sum5 = 0;
      for (i = 100; i < 228; i++)
        sum5 += gyr_y[i];
      f.push(sum5 / 128);

      var sum6 = 0;
      for (i = 100; i < 228; i++)
        sum6 += gyr_z[i];
      f.push(sum6 / 128);

      // conpute probability of each class
      var z01 = 0;
      var z02 = 0;
      var z03 = 0;
      var z12 = 0;
      var z13 = 0;
      var z23 = 0;
      for (i = 0; i < 6; i++) {
        z01 += f[i] * w01[i];
        z02 += f[i] * w02[i];
        z03 += f[i] * w03[i];
        z12 += f[i] * w12[i];
        z13 += f[i] * w13[i];
        z23 += f[i] * w23[i];
      }
      z01 += b01;
      z02 += b02;
      z03 += b03;
      z12 += b12;
      z13 += b13;
      z23 += b23;

      var p = [0, 0, 0, 0];
      p[0] = 1 / (1 + Math.exp(-z01) + Math.exp(-z02) + Math.exp(-z03));
      p[1] = 1 / (1 + Math.exp(z01) + Math.exp(-z12) + Math.exp(-z13));
      p[2] = 1 / (1 + Math.exp(z02) + Math.exp(z12) + Math.exp(-z23));
      p[3] = 1 / (1 + Math.exp(z03) + Math.exp(z13) + Math.exp(z23));

      var num = 0;
      for (i = 2; i < 230; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 2; i < 230; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 2; i < 230; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 2; i < 230; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 6; i < 226; i++) {
        if (acc_x[i] - 0.001 > acc_x[i - 6] && acc_x[i] - 0.001 > acc_x[i - 4] && acc_x[i] - 0.001 > acc_x[i - 2] && acc_x[i] - 0.001 > acc_x[i + 6] && acc_x[i] - 0.001 > acc_x[i + 4] && acc_x[i] - 0.001 > acc_x[i + 2]) {
          num = num + 1;
        }
      }
      if (p[0] > 0.6) {
        wx.showToast({
          title: action[0],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[0];
        num_0 = num_0+num;
      } else if (p[1] > 0.6) {
        wx.showToast({
          title: action[1],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[1];
        num_1 = num_1+num;
      } else if (p[2] > 0.6) {
        wx.showToast({
          title: action[2],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[2];
        num_2 = num_2+num;
      } else if (p[3] > 0.6) {
        wx.showToast({
          title: action[3],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[3];
        num_3 = num_3+num;
      } else {
        wx.showToast({
          title: '请重试',
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
      }
    },5000)

    setTimeout(function () {
      // feature generate
      var f = [];
      var i;
      var sum1 = 0;
      for (i = 350; i < 478; i++)
        sum1 += acc_x[i];
      f.push(sum1 / 128);

      var sum2 = 0;
      for (i = 350; i < 478; i++)
        sum2 += acc_y[i];
      f.push(sum2 / 128);

      var sum3 = 0;
      for (i = 350; i < 478; i++)
        sum3 += acc_z[i];
      f.push(sum3 / 128);

      var sum4 = 0;
      for (i = 350; i < 478; i++)
        sum4 += gyr_x[i];
      f.push(sum4 / 128);

      var sum5 = 0;
      for (i = 350; i < 478; i++)
        sum5 += gyr_y[i];
      f.push(sum5 / 128);

      var sum6 = 0;
      for (i = 350; i < 478; i++)
        sum6 += gyr_z[i];
      f.push(sum6 / 128);

      // conpute probability of each class
      var z01 = 0;
      var z02 = 0;
      var z03 = 0;
      var z12 = 0;
      var z13 = 0;
      var z23 = 0;
      for (i = 0; i < 6; i++) {
        z01 += f[i] * w01[i];
        z02 += f[i] * w02[i];
        z03 += f[i] * w03[i];
        z12 += f[i] * w12[i];
        z13 += f[i] * w13[i];
        z23 += f[i] * w23[i];
      }
      z01 += b01;
      z02 += b02;
      z03 += b03;
      z12 += b12;
      z13 += b13;
      z23 += b23;

      var p = [0, 0, 0, 0];
      p[0] = 1 / (1 + Math.exp(-z01) + Math.exp(-z02) + Math.exp(-z03));
      p[1] = 1 / (1 + Math.exp(z01) + Math.exp(-z12) + Math.exp(-z13));
      p[2] = 1 / (1 + Math.exp(z02) + Math.exp(z12) + Math.exp(-z23));
      p[3] = 1 / (1 + Math.exp(z03) + Math.exp(z13) + Math.exp(z23));

      var num = 0;
      for (i = 252; i < 480; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 252; i < 480; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 252; i < 480; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 252; i < 480; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 256; i < 476; i++) {
        if (acc_x[i] - 0.001 > acc_x[i - 6] && acc_x[i] - 0.001 > acc_x[i - 4] && acc_x[i] - 0.001 > acc_x[i - 2] && acc_x[i] - 0.001 > acc_x[i + 6] && acc_x[i] - 0.001 > acc_x[i + 4] && acc_x[i] - 0.001 > acc_x[i + 2]) {
          num = num + 1;
        }
      }
      if (p[0] > 0.6) {
        wx.showToast({
          title: action[0],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[0];
        num_0 = num_0+num;
      } else if (p[1] > 0.6) {
        wx.showToast({
          title: action[1],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[1];
        num_1 = num_1+num;
      } else if (p[2] > 0.6) {
        wx.showToast({
          title: action[2],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[2];
        num_2 = num_2+num;
      } else if (p[3] > 0.6) {
        wx.showToast({
          title: action[3],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[3];
        num_3 = num_3+num;
      } else {
        wx.showToast({
          title: '请重试',
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
      }
    },10000)

    setTimeout(function () {
      // feature generate
      var f = [];
      var i;
      var sum1 = 0;
      for (i = 600; i < 728; i++)
        sum1 += acc_x[i];
      f.push(sum1 / 128);

      var sum2 = 0;
      for (i = 600; i < 728; i++)
        sum2 += acc_y[i];
      f.push(sum2 / 128);

      var sum3 = 0;
      for (i = 600; i < 728; i++)
        sum3 += acc_z[i];
      f.push(sum3 / 128);

      var sum4 = 0;
      for (i = 600; i < 728; i++)
        sum4 += gyr_x[i];
      f.push(sum4 / 128);

      var sum5 = 0;
      for (i = 600; i < 728; i++)
        sum5 += gyr_y[i];
      f.push(sum5 / 128);

      var sum6 = 0;
      for (i = 600; i < 728; i++)
        sum6 += gyr_z[i];
      f.push(sum6 / 128);

      // conpute probability of each class
      var z01 = 0;
      var z02 = 0;
      var z03 = 0;
      var z12 = 0;
      var z13 = 0;
      var z23 = 0;
      for (i = 0; i < 6; i++) {
        z01 += f[i] * w01[i];
        z02 += f[i] * w02[i];
        z03 += f[i] * w03[i];
        z12 += f[i] * w12[i];
        z13 += f[i] * w13[i];
        z23 += f[i] * w23[i];
      }
      z01 += b01;
      z02 += b02;
      z03 += b03;
      z12 += b12;
      z13 += b13;
      z23 += b23;

      var p = [0, 0, 0, 0];
      p[0] = 1 / (1 + Math.exp(-z01) + Math.exp(-z02) + Math.exp(-z03));
      p[1] = 1 / (1 + Math.exp(z01) + Math.exp(-z12) + Math.exp(-z13));
      p[2] = 1 / (1 + Math.exp(z02) + Math.exp(z12) + Math.exp(-z23));
      p[3] = 1 / (1 + Math.exp(z03) + Math.exp(z13) + Math.exp(z23));

      var num = 0;
      for (i = 502; i < 730; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 502; i < 730; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 502; i < 730; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 502; i < 730; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 506; i < 726; i++) {
        if (acc_x[i] - 0.001 > acc_x[i - 6] && acc_x[i] - 0.001 > acc_x[i - 4] && acc_x[i] - 0.001 > acc_x[i - 2] && acc_x[i] - 0.001 > acc_x[i + 6] && acc_x[i] - 0.001 > acc_x[i + 4] && acc_x[i] - 0.001 > acc_x[i + 2]) {
          num = num + 1;
        }
      }
      if (p[0] > 0.6) {
        wx.showToast({
          title: action[0],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[0];
        num_0 = num_0+num;
      } else if (p[1] > 0.6) {
        wx.showToast({
          title: action[1],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[1];
        num_1 = num_1+num;
      } else if (p[2] > 0.6) {
        wx.showToast({
          title: action[2],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[2];
        num_2 = num_2+num;
      } else if (p[3] > 0.6) {
        wx.showToast({
          title: action[3],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[3];
        num_3 = num_3+num;
      } else {
        wx.showToast({
          title: '请重试',
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
      }
    },15000)

    setTimeout(function () {
      // feature generate
      var f = [];
      var i;
      var sum1 = 0;
      for (i = 850; i < 978; i++)
        sum1 += acc_x[i];
      f.push(sum1 / 128);

      var sum2 = 0;
      for (i = 850; i < 978; i++)
        sum2 += acc_y[i];
      f.push(sum2 / 128);

      var sum3 = 0;
      for (i = 850; i < 978; i++)
        sum3 += acc_z[i];
      f.push(sum3 / 128);

      var sum4 = 0;
      for (i = 850; i < 978; i++)
        sum4 += gyr_x[i];
      f.push(sum4 / 128);

      var sum5 = 0;
      for (i = 850; i < 978; i++)
        sum5 += gyr_y[i];
      f.push(sum5 / 128);

      var sum6 = 0;
      for (i = 850; i < 978; i++)
        sum6 += gyr_z[i];
      f.push(sum6 / 128);

      // conpute probability of each class
      var z01 = 0;
      var z02 = 0;
      var z03 = 0;
      var z12 = 0;
      var z13 = 0;
      var z23 = 0;
      for (i = 0; i < 6; i++) {
        z01 += f[i] * w01[i];
        z02 += f[i] * w02[i];
        z03 += f[i] * w03[i];
        z12 += f[i] * w12[i];
        z13 += f[i] * w13[i];
        z23 += f[i] * w23[i];
      }
      z01 += b01;
      z02 += b02;
      z03 += b03;
      z12 += b12;
      z13 += b13;
      z23 += b23;

      var p = [0, 0, 0, 0];
      p[0] = 1 / (1 + Math.exp(-z01) + Math.exp(-z02) + Math.exp(-z03));
      p[1] = 1 / (1 + Math.exp(z01) + Math.exp(-z12) + Math.exp(-z13));
      p[2] = 1 / (1 + Math.exp(z02) + Math.exp(z12) + Math.exp(-z23));
      p[3] = 1 / (1 + Math.exp(z03) + Math.exp(z13) + Math.exp(z23));

      var num = 0;
      for (i = 752; i < 980; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 752; i < 980; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 752; i < 980; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 752; i < 980; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 756; i < 976; i++) {
        if (acc_x[i] - 0.001 > acc_x[i - 6] && acc_x[i] - 0.001 > acc_x[i - 4] && acc_x[i] - 0.001 > acc_x[i - 2] && acc_x[i] - 0.001 > acc_x[i + 6] && acc_x[i] - 0.001 > acc_x[i + 4] && acc_x[i] - 0.001 > acc_x[i + 2]) {
          num = num + 1;
        }
      }
      if (p[0] > 0.6) {
        wx.showToast({
          title: action[0],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[0];
        num_0 = num_0+num;
      } else if (p[1] > 0.6) {
        wx.showToast({
          title: action[1],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[1];
        num_1 = num_1+num;
      } else if (p[2] > 0.6) {
        wx.showToast({
          title: action[2],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[2];
        num_2 = num_2+num;
      } else if (p[3] > 0.6) {
        wx.showToast({
          title: action[3],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[3];
        num_3 = num_3+num;
      } else {
        wx.showToast({
          title: '请重试',
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
      }
    },20000)

    setTimeout(function () {
      // feature generate
      var f = [];
      var i;
      var sum1 = 0;
      for (i = 1100; i < 1228; i++)
        sum1 += acc_x[i];
      f.push(sum1 / 128);

      var sum2 = 0;
      for (i = 1100; i < 1228; i++)
        sum2 += acc_y[i];
      f.push(sum2 / 128);

      var sum3 = 0;
      for (i = 1100; i < 1228; i++)
        sum3 += acc_z[i];
      f.push(sum3 / 128);

      var sum4 = 0;
      for (i = 1100; i < 1228; i++)
        sum4 += gyr_x[i];
      f.push(sum4 / 128);

      var sum5 = 0;
      for (i = 1100; i < 1228; i++)
        sum5 += gyr_y[i];
      f.push(sum5 / 128);

      var sum6 = 0;
      for (i = 1100; i < 1228; i++)
        sum6 += gyr_z[i];
      f.push(sum6 / 128);

      // conpute probability of each class
      var z01 = 0;
      var z02 = 0;
      var z03 = 0;
      var z12 = 0;
      var z13 = 0;
      var z23 = 0;
      for (i = 0; i < 6; i++) {
        z01 += f[i] * w01[i];
        z02 += f[i] * w02[i];
        z03 += f[i] * w03[i];
        z12 += f[i] * w12[i];
        z13 += f[i] * w13[i];
        z23 += f[i] * w23[i];
      }
      z01 += b01;
      z02 += b02;
      z03 += b03;
      z12 += b12;
      z13 += b13;
      z23 += b23;

      var p = [0, 0, 0, 0];
      p[0] = 1 / (1 + Math.exp(-z01) + Math.exp(-z02) + Math.exp(-z03));
      p[1] = 1 / (1 + Math.exp(z01) + Math.exp(-z12) + Math.exp(-z13));
      p[2] = 1 / (1 + Math.exp(z02) + Math.exp(z12) + Math.exp(-z23));
      p[3] = 1 / (1 + Math.exp(z03) + Math.exp(z13) + Math.exp(z23));

      var num = 0;
      for (i = 1002; i < 1230; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 1002; i < 1230; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 1002; i < 1230; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 1002; i < 1230; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 1006; i < 1226; i++) {
        if (acc_x[i] - 0.001 > acc_x[i - 6] && acc_x[i] - 0.001 > acc_x[i - 4] && acc_x[i] - 0.001 > acc_x[i - 2] && acc_x[i] - 0.001 > acc_x[i + 6] && acc_x[i] - 0.001 > acc_x[i + 4] && acc_x[i] - 0.001 > acc_x[i + 2]) {
          num = num + 1;
        }
      }
      if (p[0] > 0.6) {
        wx.showToast({
          title: action[0],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[0];
        num_0 = num_0+num;
      } else if (p[1] > 0.6) {
        wx.showToast({
          title: action[1],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[1];
        num_1 = num_1+num;
      } else if (p[2] > 0.6) {
        wx.showToast({
          title: action[2],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[2];
        num_2 = num_2+num;
      } else if (p[3] > 0.6) {
        wx.showToast({
          title: action[3],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[3];
        num_3 = num_3+num;
      } else {
        wx.showToast({
          title: '请重试',
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
      }
    },25000)

    setTimeout(function () {
      // feature generate
      var f = [];
      var i;
      var sum1 = 0;
      for (i = 1350; i < 1478; i++)
        sum1 += acc_x[i];
      f.push(sum1 / 128);

      var sum2 = 0;
      for (i = 1350; i < 1478; i++)
        sum2 += acc_y[i];
      f.push(sum2 / 128);

      var sum3 = 0;
      for (i = 1350; i < 1478; i++)
        sum3 += acc_z[i];
      f.push(sum3 / 128);

      var sum4 = 0;
      for (i = 1350; i < 1478; i++)
        sum4 += gyr_x[i];
      f.push(sum4 / 128);

      var sum5 = 0;
      for (i = 1350; i < 1478; i++)
        sum5 += gyr_y[i];
      f.push(sum5 / 128);

      var sum6 = 0;
      for (i = 1350; i < 1478; i++)
        sum6 += gyr_z[i];
      f.push(sum6 / 128);

      // conpute probability of each class
      var z01 = 0;
      var z02 = 0;
      var z03 = 0;
      var z12 = 0;
      var z13 = 0;
      var z23 = 0;
      for (i = 0; i < 6; i++) {
        z01 += f[i] * w01[i];
        z02 += f[i] * w02[i];
        z03 += f[i] * w03[i];
        z12 += f[i] * w12[i];
        z13 += f[i] * w13[i];
        z23 += f[i] * w23[i];
      }
      z01 += b01;
      z02 += b02;
      z03 += b03;
      z12 += b12;
      z13 += b13;
      z23 += b23;

      var p = [0, 0, 0, 0];
      p[0] = 1 / (1 + Math.exp(-z01) + Math.exp(-z02) + Math.exp(-z03));
      p[1] = 1 / (1 + Math.exp(z01) + Math.exp(-z12) + Math.exp(-z13));
      p[2] = 1 / (1 + Math.exp(z02) + Math.exp(z12) + Math.exp(-z23));
      p[3] = 1 / (1 + Math.exp(z03) + Math.exp(z13) + Math.exp(z23));

      var num = 0;
      for (i = 1252; i < 1480; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 1252; i < 1480; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 1252; i < 1480; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 1252; i < 1480; i++) {
        acc_x[i] = acc_x.slice(i - 2, i + 3).sort()[2];
      }
      for (i = 1256; i < 1476; i++) {
        if (acc_x[i] - 0.001 > acc_x[i - 6] && acc_x[i] - 0.001 > acc_x[i - 4] && acc_x[i] - 0.001 > acc_x[i - 2] && acc_x[i] - 0.001 > acc_x[i + 6] && acc_x[i] - 0.001 > acc_x[i + 4] && acc_x[i] - 0.001 > acc_x[i + 2]) {
          num = num + 1;
        }
      }
      if (p[0] > 0.6) {
        wx.showToast({
          title: action[0],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[0];
        num_0 = num_0+num;
      } else if (p[1] > 0.6) {
        wx.showToast({
          title: action[1],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[1];
        num_1 = num_1+num;
      } else if (p[2] > 0.6) {
        wx.showToast({
          title: action[2],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[2];
        num_2 = num_2+num;
      } else if (p[3] > 0.6) {
        wx.showToast({
          title: action[3],
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
        which = action[3];
        num_3 = num_3+num;
      } else {
        wx.showToast({
          title: '请重试',
          icon: 'succes',
          mask: true,
          duration: 2000,
        })
      }
    },30000)

    var that = this;
    setTimeout(function () {
      wx.showToast({
        title: '计时结束',
        icon: 'succes',
        mask: true,
        duration: 1000,
      })

      that.setData({
        num_0: num_0,
        num_1: num_1,
        num_2: num_2,
        num_3: num_3,
      })
      wx.stopAccelerometer({})
      wx.stopGyroscope({})
      var num = 0;
      console.log(num);
    }, 30000)
  }
})